# Proposal

## What will (likely) be the title of your project?

Find a Food Bank

## In just a sentence or two, summarize your project. (E.g., "A website that lets you buy and sell stocks.")

A website that allows individuals in the UK to find local banks and search for food banks based on their needs.

## In a paragraph or more, detail your project. What will your software do? What features will it have? How will it be executed?

The user (in the UK) will be able to input their postcode to find food banks near them. They can then find results returning local food banks, as well as their information (contact, location) and needs (what foods they need).
The user will also be able to enter food they have into a search bar that would return food bank results with those specific needs.

## If planning to combine CS50's final project with another course's final project, with which other course? And which aspect(s) of your proposed project would relate to CS50, and which aspect(s) would relate to the other course?

TODO, if applicable

## If planning to collaborate with 1 or 2 classmates for the final project, list their names, email addresses, and the names of their assigned TFs below.

TODO, if applicable

## In the world of software, most everything takes longer to implement than you expect. And so it's not uncommon to accomplish less in a fixed amount of time than you hope.

### In a sentence (or list of features), define a GOOD outcome for your final project. I.e., what WILL you accomplish no matter what?

A good outcome would be a website that properly takes input for each user and returns results for food banks without the program breaking.

### In a sentence (or list of features), define a BETTER outcome for your final project. I.e., what do you THINK you can accomplish before the final project's deadline?

A better outcome would be a website that also allows users to find food banks near them (by postcode) and separately, be able to conduct search results for food banks with certain needs that match what the user has in stock.

### In a sentence (or list of features), define a BEST outcome for your final project. I.e., what do you HOPE to accomplish before the final project's deadline?

The best outcome would be a website that does the above and also has an efficient search feature that allows users to input what food they have and match it to food banks with that need.
The regular food bank results and the keyword search results would be able to be sorted by distance.

## In a paragraph or more, outline your next steps. What new skills will you need to acquire? What topics will you need to research? If working with one of two classmates, who will do what?

API or database for foodbanks with their contact info, addresses, and needs. Research on how to get current location.
https://www.givefood.org.uk/api/