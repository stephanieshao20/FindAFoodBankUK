import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session

import requests
import json

# Configure application
app = Flask(__name__)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///foodbanks.db")


# global variable info
info = []


# home page
@app.route("/")
def index():
    return render_template("index.html")


# simple search page (search by postcode)
@app.route("/search", methods=["GET", "POST"])
def search():

    # search function returning food banks with the same post code
    if request.method == "POST":

        # get user post code
        postcode = request.form.get("postcode").upper()

        # check for user input
        if not postcode:
            return render_template("error.html", message="Please enter postcode")

        # find matching food banks with same postcode
        info = db.execute(
            "SELECT name, url, phone, email, address FROM foodbanks WHERE REPLACE(postcode, ' ', '')=%s", postcode.strip().replace(' ', ''))

        # if no matching food banks, return error message
        if info == []:
            return render_template("error.html", message="No results found")

        # Header of table that gets passed into html file
        message = f"Food banks with postcode {postcode}:"

        return render_template("results.html", info=info, message=message)

    # if get method is used
    return render_template("search.html")


@app.route("/advancedSearch", methods=["GET", "POST"])
def advancedSearch():

    # search function returning food banks given key terms
    if request.method == "POST":

        # get user input
        country = request.form.get("country")
        district = request.form.get("district")
        ward = request.form.get("ward")
        postcode = request.form.get("postcode")
        name = request.form.get("name")

        # if all fields are empty
        if not country and not district and not ward and not postcode and not name:
            return render_template("error.html", message="Please fill out at least one field")

        # for where statement in sql query
        where = []

        # if field is filled out, add to where statement
        # compare: case insensitive; remove whitespace from postcode; search LIKE for names
        if country:
            where.append("LOWER(country)='" + country.lower() + "'")
        if district:
            where.append("LOWER(district)='" + district.lower() + "'")
        if ward:
            where.append("LOWER(ward)='" + ward.lower() + "'")
        if postcode:
            where.append("REPLACE(postcode, ' ', '')='" + postcode.upper() + "'")
        if name:
            where.append("LOWER(name) LIKE'%" + name.lower() + "%'")

        # join where statement with AND (otherwise there would be too many entries from the country input)
        whereStatement = ' AND '.join(where)
        query = "SELECT name, url, phone, email, address FROM foodbanks WHERE {0};".format(whereStatement)

        info = db.execute(query)

        # if no results from sql query
        if info == []:
            return render_template("error.html", message="No results found")

        return render_template("results.html", info=info)

    # if get method is used
    return render_template("advancedSearch.html")


@app.route("/whydonate")
def whydonate():
    return render_template("whydonate.html")


@app.route("/results", methods=["GET", "POST"])
def results():
    if request.method == "POST":
        # info is a global variable passed in from another page
        return render_template("results.html", info=info)
    return render_template("results.html", info=info)


@app.route("/needs", methods=["GET", "POST"])
def needs():
    if request.method == "POST":

        # get user input
        needsinput = request.form.get("needs")

        # if field is not filled out
        if not needsinput:
            return render_template("error.html", message="Please enter at least one good")

        # separate goods by commas
        needs = needsinput.split(',')

        # get info from API
        response = requests.get("https://www.givefood.org.uk/api/1/needs/")
        listneeds = json.loads(response.text)

        info = []

        # goes through comma separateditems of user input
        for need in needs:
            need = need.strip().lower()

            # goes through each dictionary in the list from the API
            for foodbank in listneeds:
                infoDict = {}
                foodbankneeds = foodbank['needs'].split('\r\n')

                # goes through each need in the list in the dictionary
                for foodbankneed in foodbankneeds:

                    # render case insensitive and sans extra whitespace for comparison purposes
                    foodbankneed = foodbankneed.lower().strip()
                    if need in foodbankneed:
                        if foodbank['foodbank_name'] not in infoDict.keys():
                            infoDict['name'] = foodbank['foodbank_name']
                            infoDict['url'] = foodbank['url']
                            infoDict['needs'] = ', '.join(foodbankneeds)
                            info.append(infoDict)

        # if no results
        if info == []:
            return render_template("error.html", message="No results found")

        message = f"Food banks that need {needsinput}:"

        return render_template("needsResults.html", info=info, message=message)

    # if get method
    return render_template("needs.html")