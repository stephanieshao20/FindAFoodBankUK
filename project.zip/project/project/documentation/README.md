Youtube video: https://youtu.be/btwsVeY5-RQ

UK Food Bank Finder

The purpose of this web application is to find a food bank in the UK based on location, name, or needs.

The navigation bar (navbar) up top leads to five different pages.

The first option labeled "Nourish Others" leads to the home page (that is the default page). The home page is a simple welcome page
presenting the purpose of the web application. The main button centered on the home page leads to the simple search page (same as the third
option on the navbar). Since most of my classmates are from the US, I also included a link that would direct users to a different page (not
part of my project) where Americans can find food banks in the US via Feeding America.

The second option labeled "Why donate?" leads to a page citing statistics and why it is a good idea to donate to food banks. This is mainly
a persuasive page for those who "stumble" upon the page and aren't sure about donating to food banks. The page provides citations for
the statistics.

The third option labeled "Search by postcode" leads to a page that allows the user to conduct a simple search of food banks with a
certain postcode. The user can enter a UK postcode regardless of capitalization and spacing. The simple search page also has a link underneath
the search button leading to the advanced search page.

The fourth option labeled "Advanced search" leads to a similar search page that has multiple search fields the user can fill out. At least
one field needs to be filled out (not necessarily all of them). All search fields are case insensitive and will take out leading or trailing
white space. For example, if the country search field is filled out, but the others are blank, the search will return all the food banks in
the provided country. If more than one field is filled out, the search will narrow and provide results that match with all user inputted fields
(using AND rather than OR in the SQL query).

The fifth option labeled "Search by goods" leads to a search page where the user can input a list of goods separated by commas. The search will
return a list of food banks with at least one of those goods as a need. For example, if the user searched "corned beef, sugar", the search would
return all food banks that were recently in need of either corned beef and/or sugar. This search option does not provide location data (because
the API it was derived from didn't include location data). Thus, the user would need to enter the name of the results into the advanced search page
to find out location and contact info (aside from the website).

The simple and advanced searches will return the names, websites (hyperlinked), phone number, email address, and postal address for each
matching food bank. The goods search function will return the names, websites (hyperlinked) and lists of needs/goods.

If the error page results (if there are no results or if no search fields were filled out), a message will be on the page explaining why.
From there, the user can either use the navigation bar to move around or hit the back button on the browser.

The bottom of the page cites Give Food for the food bank data provided in the CSV/API.

