The purpose of this web application is to provide a search function for finding food banks in the UK based via three different searches:
1) A simple search via postcode (the UK version of a zipcode)
2) A more advanced search providing various different fields
3) By goods (searches through the needs of food banks and returns those with matches)
4) Get people to donate food

The data:
All the food bank data came from https://www.givefood.org.uk/api/. The food bank contact and location data was retrieved from a CSV file that I
converted into a database (.db), and both the simple and advanced searches retrieve data from this database using SQL queries. An API was later
used/implemented for the goods search, which does not include location or contact data (aside from the website url). The API was used for the
goods searched because the needs of the food banks are updated every few days and would not serve its function well as a static CSV or database
(which would not be updated through the web application, since the intended users are donors, not foodbanks). Keeping the food bank data in the
database is more organized, having SQL queries made, rather than getting a large list of dictionaries from an API and searching through them for
matching data.

Simple Search:
The simple search function takes in user input of a UK postcode (comprised of numbers and letters) and searches for a matching postcode in the
food bank database. Though postcodes are typically in all caps with a space in between, the search function will read "ab123ax" the same as
"AB12 3AX", ignoring capitalization and white space.

Advanced Search:
The advanced search function takes in different kinds of input, including country, district, ward, postcode, and name. I chose to make the search
query inclusive of all fields using "AND" instead of "OR" in order to produce narrower search results that would be more relevant to the user's
request. If "OR" was used, a user entering "Scotland" and a the name of a district in Scotland would end up with the same results as just
searching for food banks in "Scotland". Each search field is case insensitive. The "name" field also uses the "LIKE" SQL term to find food bank
names including, but not restricted to, the user input. For example, typing in "Newmarket" still returns a food bank named "Newmarket Open Door,"
even though the name is not exactly the same.

Goods Search:
The goods search is conducted a differently from the other two searches, retrieving its data from an API, rather than the database. The data
is passed from the API to a variable (listneeds) as a list of dictionaries, with each dictionary representing a food bank. There is then a
series of for loops looping through 1) the comma-separated goods from the user input, 2) the food bank dictionaries from listneeds, and
3) the needs within each food bank. When a match is found, data (name, url, list of needs) is appended as a dictionary to a list that would
be similar to the list of dictionaries returned by SQL queries.

Results:
The results HTML pages return tables that loop through the elements (dictionaries) of the passed in list using flask.
Each result comes with a hyperlinked url to the food bank's website, allowing the user to click on the link and visit the website for more info.
there is no sorting mechanism involved, which would be one feature to be considered for future implementation (if I had another 50 hours).
Another thing to consider would be finding a way to combine the search functions of both location and needs.

Error page:
If a search query was made without any fields filled in, the web application returns an error page with a message saying that at least one field
needs to be filled in. If a search query was made where no results were found, an error page was returned with a message saying no results were
found. This way, the web application doesn't just return a blank table.

Why Donate page:
This page serves the purpose of answering the question of why this web application is significant: why is it important for people to find a
food bank and donate in the first place? As for coding, most of the coding on this page was done on the front-end, with more focus on HTML/CSS.

Design / Aesthetics:
Much of the design was initially influenced by the CS50 Finance pset, but most components were changed or completely replaced. One of the most
obvious differences is the darker color scheme. Some of the more nuanced design portions that took me a long time to implement were the
background photos, which were implemented for the home page and "Why Donate?" page. A transparent box was laid over the photo for a cleaner look.
When the photo doesn't load, a similar background color is put in place instead. The buttons and navbar change color when hovered over. I took
black and white icons from thenounproject and colored them in using photoshop. There are other small nuances as well, but I won't go over all
of them.

Citations: Citing.txt can be found under the static folder.