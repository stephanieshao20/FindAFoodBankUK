# Status Report

#### Your name

Stephanie Shao

#### Your section leader's name

Masfi Khan, Megha Joshi

#### Project title

UK food bank finder

***

Short answers for the below questions suffice. If you want to alter your plan for your project (and obtain approval for the same), be sure to email your section leader directly!

#### What have you done for your project so far?

It took me a day to figure out how to convert my csv file into a database, but I eventually figured it out. I also took a long time to
figure out how to implement a background photo.

I've created the pages, and laid out how I want them all the link to each other. I've implemented a navbar and two different search functions
(one simple one that searches by postcode and one advanced one where the user can input multiple fields).

I made small icons for my navbar by getting icons from thenounproject, coloring them in with photoshop, and converting them from .png to .ico.

I also added a third search function for entering user goods to find food banks that want those goods (this is the search that needs the API).

#### What have you not done for your project yet?

I'm working on aesthetics (presentation of my flask website) and refining my search function.

#### What problems, if any, have you encountered?

It took me a long time to find out how to use the API because I thought the API link provided was just a bunch of text that I couldn't use.
So, I only implemented it long after I based my project around the database I created.

For all my search functions, I struggled with getting the sql query because the .execute function kept adding random extra quotation marks,
even though the separate statement I was appending to my query was perfectly fine (when printed). I had to get around it with different
"escape" characters.

It took at least an hour for me to get around a similar issue for my "needs" search, but when it worked, I ended up scrapping it to
return different output with info from the API, rather than the database, so I didn't need the sql query anymore.